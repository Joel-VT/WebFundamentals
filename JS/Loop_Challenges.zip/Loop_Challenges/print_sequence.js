var x = 4;
while(x >= -3.5){
    console.log(x);
    x -= 1.5;
}