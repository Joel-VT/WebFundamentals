console.log("page loaded...");

function vidplay(element) {
    console.log(element);
    element.play();
}

function vidpause(element) {
    console.log(element);
    element.pause();
}